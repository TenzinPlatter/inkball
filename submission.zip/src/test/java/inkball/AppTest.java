package inkball;

import org.junit.jupiter.api.Test;

class AppTest {

  @Test
  void loadLevels() {
  }

  @Test
  void loadSprites() {
  }

  @Test
  void loadImageFromPath() {
  }

  @Test
  void getColorCode() {
  }

  @Test
  void addScore() {
  }

  @Test
  void drawScore() {
  }
}
